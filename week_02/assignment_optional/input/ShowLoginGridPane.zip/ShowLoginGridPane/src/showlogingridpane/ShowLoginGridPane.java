/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package showlogingridpane;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

public class ShowLoginGridPane extends Application{
    
    @Override 
    public void start(Stage myStage){
        GridPane myGrid = new GridPane();
        myGrid.setPadding(new Insets(10, 10, 10 ,10));
        myGrid.setVgap(10);
        myGrid.setHgap(10);
        
        Label lblName = new Label("Username:");
        TextField txtName = new TextField();
        Label lblPwd = new Label("Password:");
        TextField txtPwd = new TextField();        
        txtPwd.setPromptText("password");
        Button btnLogin = new Button("Log in");
        
       // πρώτος τρόπος: χρήση μεθόδου add() για προσθήκη control 
       // και θέσης ταυτόχρονα στο grid 
        myGrid.add(lblName, 0, 0);
        //προσθέστε το txtName στο Grid
        //προσθέστε το lblPwd στο Grid
        //προσθέστε το txtPwd στο Grid
        //προσθέστε το btnLogin στο Grid
       
        
        /* δεύτερος τρόπος: χρήση στατικής μεθόδου setConstraints()  */
        GridPane.setConstraints(lblName, 0, 0);
        //προσθέστε το txtName στο Grid
        //προσθέστε το lblPwd στο Grid
        //προσθέστε το txtPwd στο Grid
        //προσθέστε το btnLogin στο Grid
        //προσθέστε όλα τα controls στο pane
        
        Scene myScene = new Scene(myGrid, 250, 115);
        
        myStage.setTitle("Login screen");
        myStage.setScene(myScene);        
        myStage.show();        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Application.launch(args);
    }
    
}
