/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package showflowpane;
import javafx.application.Application;

import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;

public class ShowFlowPane extends Application{
    @Override
    public void start(Stage myStage){
        //Δημιουργία FlowPane
        FlowPane myPane = new FlowPane();
        myPane.setOrientation();  //Θέστε  προσανατολισμό
        myPane.setPadding(); //Θέστε ανω, κάτω, αριστερό και δεξί περιθώριο
        myPane.setHgap(5);  //θέστε οριζόντιο περιθώριο μεταξύ των εικόνων
        myPane.setVgap(5);  //θέστε κατακόρυφο περιθώριο μεταξύ των εικόνων
        
        //Δημιουργία control nodes και τοποθέτησή τους εντος του pane
        Label lblName = new Label("First Name:");         
        TextField txtName = new TextField();        
        //Δημιουργία lblMiddleName
        //Δημιουργία txtMiddleName 
        
        //Δημιουργία lblLastName
        //Δημιουργία txtLastName
                       
        //Προσθήκη κόμβων στο pane
        //txtMiddleName, lblLastName, txtSirName);                
        
        //Δημιουργία σκηνικού διαστάσεων 250 χ 250 και προσθήκη του pane σε αυτό
        
        //Προσθήκη σκηνικού στο παράθυρο
        
        //Προσθήκη τίτλου "show Flow pane"
        
        //Εμφάνιση του παραθύρου
        
    }
    
    public static void main(String[] args) {
     Application.launch(args);
    }    
}
