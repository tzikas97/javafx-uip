/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise7_1;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author Kostas Tsiknas
 */
public class Exercise7_1 extends Application{
    private TextField tfAnnualInterestRate = new TextField();
    private TextField tfNumberOfYears = new TextField();
    private TextField tfLoanAmount = new TextField();
    private TextField tfMonthlyPayment = new TextField();
    private TextField tfTotalPayment = new TextField();
    private Button btnCalculate = new Button("Calculate");
    
    public void start(Stage myStage){
        
        GridPane gridPane = new GridPane();                        
        gridPane.setPadding(new Insets(10,10,10,10));
        gridPane.setHgap(5);
        gridPane.setVgap(5);
        
        //προσθήκη των πεδίων (label, textFields) στη διάταξη

        
        
        
        //δεξιά στοίχιση των τιμών στα πεδία κειμένου (textFields)
        
        
        
        //μετατροπή των δύο τελευταίων πεδίων σε  read-only
        
        
        
        
        //κλήση της calculateLoanPayment() για τη διαχείριση του πατήματος κουμπιού 

        
        Scene scene = new Scene(gridPane);
        myStage.setTitle("LoanCalculator");
        myStage.setScene(scene);
        myStage.show();
    }
    
    private void calculateLoanPayment() {
        
        //ανάγνωση των τιμών των πεδίων interest, year, loanAmount        
        
        
        //Δημιουργία αντικειμένου της κλάσης loan και ταυτόχρονη κλήση του constructor
        //με τα κατάλληλα ορίσματα
        
        
        //κλήση των getMonthlyPayment(), getTotalPayment() για την εξαγωγή της μηνιαίας
        //δόσης και του συνολικού ποσού και τοποθέτηση των τιμών αυτών στα αντίστοιχα πεδία
 
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
