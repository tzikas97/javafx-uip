/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise6_3;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 *
 * @author Kostas Tsiknas
 */
public class Exercise6_3 extends Application{
   
   private final int STEP = 10;
   private Circle circle = new DrawCircle(50,Color.WHITE, Color.BLACK);   
    
   @Override
    public void start(Stage myStage){
        HBox hBox = new HBox();
        hBox.setPadding(new Insets(20,20,20,20));
        hBox.setSpacing(20);
        hBox.setAlignment(Pos.CENTER);

        Button btnEnlarge = new Button("Enlarge");
        Button btnShrink = new Button("Shrink");
        hBox.getChildren().add(btnEnlarge);
        hBox.getChildren().add(btnShrink);
               
        btnEnlarge.setOnAction(e -> enlarge());                
        btnShrink.setOnAction(e -> shrink());  

        BorderPane borderPane = new BorderPane();        
        borderPane.setCenter(circle);
        borderPane.setBottom(hBox);
        BorderPane.setAlignment(hBox, Pos.CENTER);
        
        Scene scene = new Scene(borderPane, 400, 400);
        myStage.setTitle("Exercise 6.3");
        myStage.setScene(scene);
        myStage.show();        
    }
    
    public void enlarge() {
            circle.setRadius(circle.getRadius() + STEP);
    }

    public void shrink() {
            circle.setRadius(circle.getRadius() - STEP);
    }
       
    public class DrawCircle extends Circle {
        public DrawCircle(int radius, Color fillColor, Color StrokeColor){
            super(radius, fillColor);
            setStroke(StrokeColor);
        }
    }
       
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
