/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise6_1;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Kostas Tsiknas
 */
public class Exercise6_1 extends Application{
    @Override
    public void start(Stage myStage){

        Button btnOK = new Button("Test"); 
        btnOK.setOnAction( new EventHandler<ActionEvent>(){              
        public void handle(ActionEvent event){
            StackPane  stackPane = new StackPane(new Label("Button test pressed!"));
            Scene newScene = new Scene(stackPane, 300, 200);                
            Stage newStage = new Stage();
            newStage.setTitle("Example window");
            newStage.setScene(newScene);
            newStage.show();
          }
        });
              
        HBox hBox = new HBox();
        hBox.setPadding(new Insets(50, 100, 50, 100));
        hBox.setSpacing(20);
        hBox.setAlignment(Pos.CENTER);
        hBox.getChildren().add(btnOK);
        
        Scene scene = new Scene(hBox);
        myStage.setTitle("Exercise 6.1");
        myStage.setScene(scene);
        myStage.show();
    }
    
         public static void main(String[] args) {
        launch(args);
     }
    
}
