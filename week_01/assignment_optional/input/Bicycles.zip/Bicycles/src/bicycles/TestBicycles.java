/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bicycles;

/**
 *
 * @author Kostas Tsiknas
 */
public class TestBicycles {
    
        public static void main(String[] args) {
        Bicycles bike1 = new Bicycles();
        
        bike1.speed = -10;
        System.out.println(bike1.speed);
    }
}
