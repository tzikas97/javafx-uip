/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bicycles;

/**
 *
 * @author Kostas Tsiknas
 */
public class Bicycles {
    
    private int gear;
    public int speed;
    
    public Bicycle(){
        gear = 1;        
    }
    
}
