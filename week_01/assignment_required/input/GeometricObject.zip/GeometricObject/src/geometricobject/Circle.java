/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricobject;

/**
 *
 * @author Kostas Tsiknas
 */
public class Circle extends GeometricObject{
    private double radious =0;
    
    public Circle(){    
    };
    
    public Circle(double radious){
        this.radious = radious;
    };
    
    public double getRadious(){
        return radious;
    }
    
    public void setRadious(double radious){
        this.radious = radious;
    }
    
    public double getArea(){
        return radious * radious * Math.PI;
    }
     
    public double getPerimeter(){
        return 2 * radious * Math.PI;
    }
    
    public double getDiameter(){
        return 2 * radious;
    }

    /** Προσθέστε τα σχόλιά σας εδώ**/
    @Override
    public String toString(){
        return "Circle " + super.toString() + "\nRadious: " + radious;
    }
    
    
}
