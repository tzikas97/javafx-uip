/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricobject;

import java.util.Date;

/**
 *
 * @author Kostas Tsiknas
 */
public class GeometricObject {
    private String color = "white";
    private boolean filled;
    private Date dateCreated;
    
    /** Κατασκευή προεπιλεγμένου γεωμετρικού αντικειμένου. Η ημερομηνία 
     * λαμβάνεται από το σύστημα **/
    public GeometricObject(){
        dateCreated = new Date();
    }

    /** Κατασκευάζει ένα προεπιλεγμένο γεωμετρικό αντικείμενο με καθορισμένο 
     * χρώμα και τιμή γεμίσματος. Η ημερομηνία λαμβάνεται από το σύστημα
     * */
    public GeometricObject(String color, boolean filled){
        this.color = color; 
        this.filled = filled;
        this.dateCreated = new Date();
    }
    
    /** Επιστρέφει χρώμα **/
    public String getColor() {
            return color;
    }
    
    /** Επιστρέφει την τιμή γεμίσματος filled. Επειδή η filled είναι δυαδική,
     * η μέθοδος λήψης ονομάζεται isFilled  **/
    public boolean isFilled() {
        return filled;
    }
    
    /** Επιστρέφει την ημέρομηνία δημιουργίας του αντικειμένου **/
    public Date getDateCreated() {
        return dateCreated;
    }
    
    /** Θέτει νέα τιμή στην color **/
    public void setColor(String color) {
        this.color = color;
    }
    
    /** Θέτει νέα τιμή στη filled **/
    public void setFilled(boolean filled) {
        this.filled = filled;
    }
    
    /** Επιστρέφει μια αναπαράσταση του αντικειμένου σε μορφή αλφαριθμητικού **/
    public String toString(){
        return "created on " + dateCreated + "\ncolor: " + color +
                " and filled: " + filled;                
    }
    
    
}