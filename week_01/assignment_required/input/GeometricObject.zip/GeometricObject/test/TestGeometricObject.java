
import geometricobject.GeometricObject;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kostas Tsiknas
 */
public class TestGeometricObject {
    public static void main(String[] args)
    {
        GeometricObject obj1 = new GeometricObject();
        GeometricObject obj2 = new GeometricObject("blue", true);
        System.out.println("Object 1: " + obj1.toString());
        System.out.println("Object 2: " + obj2.toString());
    }
}
