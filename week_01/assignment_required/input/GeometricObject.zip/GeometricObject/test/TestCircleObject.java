/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import geometricobject.Circle;
/**
 *
 * @author Kostas Tsiknas
 */
public class TestCircleObject {
    public static void main(String[] args){
        Circle obj1 = new Circle(2.2);
        
        System.out.println("Color: " + obj1.getColor());
        System.out.println("Area: " + obj1.getArea());
        System.out.println("Perimeter: " + obj1.getPerimeter());
        System.out.println("Diameter: " + obj1.getDiameter());                
    }
    
}
